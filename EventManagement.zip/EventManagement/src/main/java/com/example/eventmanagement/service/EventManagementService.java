package com.example.eventmanagement.service;

import com.example.eventmanagement.dto.Attendee;
import com.example.eventmanagement.dto.Event;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class EventManagementService {
    public static Set<Event> eventList = new HashSet<>();
    public static Set<Attendee> attendeeList = new HashSet<>();

    public static Set<Event> getEventList() {
        eventList.add(new Event(1, "Flowers-Show", "Amazing view of flower show", LocalDateTime.now(), "Bangalore", 5));
        eventList.add(new Event(2, "Stanch IO event", "Interview ", LocalDateTime.now(), "Bangalore", 2));
        return eventList;
    }
    public static Set<Attendee> getAttendeeList() {
        attendeeList.add(new Attendee(1,"Raghu",2));
        attendeeList.add(new Attendee(2,"Vikas",1));
        return attendeeList;
    }


    public String addEvent(Event event) {
        if (event != null) {
            eventList.add(event);
            return "Successfully added the new Event";
        }
        return "Please add event";
    }

    public String updateEvent(Event event) {
        Event updateEvent = new Event();
        if (event != null) {
            if (eventList.contains(event))
                return "Event already exists";
            else {
                if (event.getEventId() != 0) {
                    updateEvent.setEventId(event.getEventId());
                    updateEvent.setTitle(event.getTitle());
                    updateEvent.setDescription(event.getDescription());
                    updateEvent.setDate(event.getDate());
                    updateEvent.setLocation(event.getLocation());
                }
            }
        }
        return "Event updated";
    }

    public String deleteEvent(Event deleteEvent) {
        if (deleteEvent != null) {
            eventList.remove(deleteEvent);
            return "Successfully deleted the event";
        }
            return "Event not found";
    }

    public Set<Attendee> getAttendeeListByEventId(int eventId) {
        return attendeeList.stream().filter(p -> p.getEventId()==eventId).collect(Collectors.toSet());
    }
    public String addAttendee(Attendee attendee) {
        attendeeList.add(attendee);
        return "Successfully added the new Attendee";
    }
    public String updateAttendee(Attendee attendee) {
        Attendee updateAttendee = new Attendee();
        if (attendee != null) {
            updateAttendee.setId(attendee.getId());
            updateAttendee.setEventId(attendee.getEventId());
            updateAttendee.setName(attendee.getName());
            attendeeList.add(updateAttendee);
            return "Successfully updated the new Attendee";
        }else {
            return "Please pass a valid attendee";
        }
    }
    public String deleteAttendee(Attendee attendee) {
        if (attendee != null) {
            attendeeList.remove(attendee);
            return "Successfully deleted the attendee";
        }
        return "Please pass a valid attendee/Attendee not found";
    }


}
