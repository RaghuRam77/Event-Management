package com.example.eventmanagement.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Event {
    private int eventId;
    private String title;
    private String description;
    private LocalDateTime date;
    public String location;
    public int capacity;
}
