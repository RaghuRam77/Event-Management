package com.example.eventmanagement.controller;

import com.example.eventmanagement.dto.Attendee;
import com.example.eventmanagement.dto.Event;
import com.example.eventmanagement.service.EventManagementService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Set;

@RestController
public class EventManagementController {

    @Autowired
    private EventManagementService eventManagementService;

    @GetMapping(value = "events",produces = "application/json")
    public Set<Event> getAllEventsList() {
        return eventManagementService.getEventList();
    }

    @PostMapping(value = "addevent", consumes = "application/json")
    public String addEvent(@RequestBody Event event) {
        return eventManagementService.addEvent(event);
    }

    @PutMapping(value = "updateevent", consumes = "application/json")
    public String updateEvent(@RequestBody Event event) {
        return eventManagementService.updateEvent(event);
    }
    @DeleteMapping(value = "deleteEvent")
    public String deleteEvent(@RequestBody Event event) {
        return eventManagementService.deleteEvent(event);
    }
    @GetMapping(value = "attendee-by-eventId/{eventId}", produces = "application/json")
    public Set<Attendee> getAttendeeByEventId(@PathVariable("eventId") int eventId) {
        return eventManagementService.getAttendeeListByEventId(eventId);
    }
    @PostMapping(value="addAttende",consumes = "application/json")
    public String addAttendee(@RequestBody Attendee attendee) {
        return eventManagementService.addAttendee(attendee);
    }
    @PutMapping(value="updateAttende",consumes = "application/json")
        public String updateAttendee(@RequestBody Attendee updateAttendee){
            return eventManagementService.updateAttendee(updateAttendee);
    }
    @DeleteMapping(value="deleteAttendee",consumes = "application/json")
    public String deleteAttendee(@RequestBody Attendee deleteAttendee){
        return eventManagementService.deleteAttendee(deleteAttendee);
    }
}
