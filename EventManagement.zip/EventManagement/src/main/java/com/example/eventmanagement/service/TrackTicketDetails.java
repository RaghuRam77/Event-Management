//package com.example.eventmanagement.service;
//
//import com.example.eventmanagement.dto.Event;
//import com.example.eventmanagement.dto.Ticket;
//import com.opencsv.CSVParser;
//import com.opencsv.CSVParserBuilder;
//import com.opencsv.CSVReader;
//import com.opencsv.CSVReaderBuilder;
//import com.opencsv.bean.ColumnPositionMappingStrategy;
//import com.opencsv.bean.CsvToBeanBuilder;
//import org.springframework.stereotype.Service;
//
//import java.io.BufferedReader;
//import java.io.FileReader;
//import java.util.ArrayList;
//import java.util.List;
//import java.util.Optional;
//
//@Service
//public class TrackTicketDetails {
//    public static List<Ticket> getListOfTickets() {
//        List<Ticket> tickets = new ArrayList<>();
//        tickets.add(new Ticket(1, 1, "Flowers-show"));
//        tickets.add(new Ticket(2, 1, "Flowers-show"));
//        tickets.add(new Ticket(3, 1, "Flowers-show"));
//        tickets.add(new Ticket(4, 2, "Stanch IO event"));
//        tickets.add(new Ticket(5, 2, "Stanch IO event"));
//        tickets.add(new Ticket(6, 2, "Stanch IO event"));
//        return tickets;
//    }
//
//
//    public static void buyTicket(int eventId) {
//        long count = getListOfTickets().stream().filter(e -> e.getEventId() == eventId).count();
//        if (count == 0) {
//            System.out.println("Tickets are sold out for this event");
//        } else {
//            Optional<Ticket> event = getListOfTickets().stream().filter(e -> e.getEventId() == eventId).findFirst();
//            getListOfTickets().removeIf(event.get()::equals);
//            System.out.println(getListOfTickets().stream().count());
//        }
//    }
//
//    public static void main(String[] args) {
//        buyTicket(2);
//        readDataFromCustomSeparator();
//    }
//
//
//    public static void readDataFromCustomSeparator() {
//        try {
//            // Set up the CSV reader and mapping strategy
//            ColumnPositionMappingStrategy<Event> strategy = new ColumnPositionMappingStrategy<>();
//            strategy.setType(Event.class);
//            strategy.setColumnMapping("name", "age", "email");
//
//            // Read the CSV file and map to the Person objects
//            CsvToBean<Event> csvToBean = new CsvToBeanBuilder<Event>(new FileReader("data.csv"))
//                    .withMappingStrategy(strategy)
//                    .build();
//            List<Person> people = csvToBean.parse();
//
//            // Process the list of Person objects
//            for (Person person : people) {
//                System.out.println("Name: " + person.getName());
//                System.out.println("Age: " + person.getAge());
//                System.out.println("Email: " + person.getEmail());
//                System.out.println();
//            }
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//    }
//}
